a = int(input("eerste gehele getal: "))
b = int(input("tweede gehele getal: "))

if a > b:
    Max = a
    print(f'a is het grootste getal: {Max}')
