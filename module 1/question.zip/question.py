naam = input("Wat is je naam? ")

leeftijd = int(input(f"Goededag {naam}, hoe oud ben je? "))

eten = input(f"En als {leeftijd} jarige, wat eet je het liefst? ")

drinken = input(f"En wat drink je het liefst bij {eten}? ")

print(f"De {leeftijd} jarige {naam} drinkt het liefst {drinken} bij {eten}.")
